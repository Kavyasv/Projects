/*package com.wallet;

import com.wallet.bean.Customer;
import com.wallet.dao.WalletDAO;
import com.wallet.dao.WalletDAOImpl;
import com.wallet.exception.WalletException;
import junit.framework.TestCase;


public class AppTest 
    extends TestCase
{
	
WalletDAO dao=new WalletDAOImpl();
   public void init() {
	   
   }
    
 public final void testCreateAccount() {
		Customer request=new Customer();
		request.setAccountNo(123456);
		request.setName("Chinnu");
		request.setAge("20");
		request.setMobileNo("9999999999");
		request.setEmail("abc@gmail.com");
		try {
			dao.createAccount(request);
			double e=dao.showBalance(123456);
			assertNotNull(e);
		}
		catch(WalletException e) {
			e.printStackTrace();
		}
	}
 public void testShowBalance() {
		try {
			double e=dao.showBalance(12345);
			assertNotNull(e);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
 public void  testcheckAccountNo() {
	 try {
		 boolean e=dao.checkAccountNo(123456);
		 assertNotNull(e);
	 }
	 catch(Exception e) {
		 e.printStackTrace();
	 }
 }
 public void testdeposit() {
	 try {
		 double e=dao.deposit(1000, 123456);
		 assertNotNull(e);
	 }
	 catch(Exception e) {
		 e.printStackTrace();
	 }
 }
 public void testwithdraw() {
	 try {
		 double e=dao.withdraw(500, 123456);
		 assertNotNull(e);
	 }
	 catch(Exception e) {
		 e.printStackTrace();
	 }
	 }
 }

*/