package com.wallet.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.junit.runner.Request;

import com.wallet.bean.Customer;
import com.wallet.bean.Transaction;
import com.wallet.exception.WalletException;
import com.wallet.util.DBConnection;

public class WalletDAOImpl implements WalletDAO {
Customer customer=new Customer();
Logger logger=Logger.getRootLogger();
int tid=0;
	
	public WalletDAOImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}

@SuppressWarnings("resource")
@Override
	public Integer createAccount(Customer request) throws WalletException {
	Connection connection = com.wallet.util.DBConnection.getInstance().getConnection();	
	
	PreparedStatement preparedStatement=null;		
	ResultSet resultSet = null;
	
	int accountNo=0;
	
	int queryResult=0;
	try
	{		
		preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

		preparedStatement.setString(1,request.getName());
		preparedStatement.setString(2, request.getAge());
		preparedStatement.setString(3, request.getAccountType());
		preparedStatement.setString(4, request.getMobileNo());
		preparedStatement.setString(5, request.getEmail());
		preparedStatement.setDouble(6, request.getBalance());
				
		queryResult=preparedStatement.executeUpdate();
	
		preparedStatement = connection.prepareStatement(QueryMapper.ACCOUNTNO_QUERY_SEQUENCE);
		resultSet=preparedStatement.executeQuery();

		if(resultSet.next())
		{
			accountNo=resultSet.getInt(1);
					
		}

		if(queryResult==0)
		{
			logger.error("Insertion failed ");
			throw new WalletException("Inserting customer details failed ");

		}
		else
		{
			logger.info("Customer details added successfully:");
			return accountNo;
		}
	 }
	catch(SQLException sqlException)
	{
		logger.error(sqlException.getMessage());
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}
	
}
	
	

	@SuppressWarnings("resource")
	@Override
	public double deposit(double b1, Integer getAccountNo) throws WalletException {
		
		Connection connection = com.wallet.util.DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;
		PreparedStatement preparedStatement1=null;
		ResultSet resultSet = null;
		ResultSet resultSet1 = null;
		double balance=0;
		
		
		int queryResult=0;
		int queryResult1=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.DEPOSIT_QUERY);
			preparedStatement.setDouble(1,b1);
			preparedStatement.setInt(2,getAccountNo);
			queryResult=preparedStatement.executeUpdate();
			 
			 preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			 preparedStatement.setInt(1,getAccountNo);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				 balance= resultSet.getDouble("Balance");
				preparedStatement1=connection.prepareStatement(QueryMapper.transfer_query1);
				preparedStatement1.setString(1,"deposit");
				preparedStatement1.setDouble(2,b1);
				preparedStatement1.setInt(4,getAccountNo);
				PreparedStatement Date=connection.prepareStatement(QueryMapper.date_query);
				resultSet1=Date.executeQuery();
				if(resultSet1.next())
				{
					Date date=resultSet1.getDate(1);
					preparedStatement1.setDate(3,(java.sql.Date) date);
					
				}
				queryResult1=preparedStatement1.executeUpdate();
				preparedStatement = connection.prepareStatement(QueryMapper.transfer_query_sequence);
				resultSet=preparedStatement.executeQuery();

				if(resultSet.next())
				{
					tid=resultSet.getInt(1);
							
				}
			}
			else
			{
				throw new WalletException("Enter correct account number ");
			}
			return balance;			

		 }
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log or Invalid account Number");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
		
	}

	@SuppressWarnings("resource")
	@Override
	public double withdraw(double b1, Integer getAccountNo) throws WalletException {
	
		
	Connection connection = com.wallet.util.DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		double balance=0;
		
		
		int queryResult=0;
		try
		{	
			preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			preparedStatement.setInt(1,getAccountNo);
	        
		    resultSet=preparedStatement.executeQuery();

			resultSet.next();
			double rs=resultSet.getDouble("balance");

			if(rs<b1)
				throw new WalletException("insufficient balance in your account");
			else {
			preparedStatement=connection.prepareStatement(QueryMapper.WITHDRAW_QUERY);
			preparedStatement.setDouble(1,b1);
			preparedStatement.setInt(2,getAccountNo);
			queryResult=preparedStatement.executeUpdate();
			 
			 preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
			 preparedStatement.setInt(1,getAccountNo);
			resultSet=preparedStatement.executeQuery();

			resultSet.next();
			
			
			balance=resultSet.getDouble("balance");
		
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new WalletException("withdraw failed ");

			}
			else
			{
				logger.info("withdraw successfully:");
				return balance;
			}
		 }}
		catch(SQLException sqlException)
		{
			logger.error(sqlException.getMessage());
			sqlException.printStackTrace();
			throw new WalletException("Tehnical problem occured refer log or Invalid account Number");
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				logger.error(sqlException.getMessage());
				throw new WalletException("Error in closing db connection");	
			}
		}
		
	
	}

	@Override
	public double showBalance(Integer accountNo) throws WalletException {
	
Connection connection = com.wallet.util.DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
	try
		{		
		preparedStatement=connection.prepareStatement(QueryMapper.SELECT_QUERY);
		preparedStatement.setInt(1,accountNo);
        
	    resultSet=preparedStatement.executeQuery();

		resultSet.next();
		double rs=resultSet.getDouble("balance");
				
		return rs;

	 }
	catch(SQLException sqlException)
	{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new WalletException("Tehnical problem occured refer log or account number validation fails");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}
		
	}

	@Override
	public boolean printTransaction(int accno) throws WalletException {
		Transaction t=new Transaction();
		Connection connection = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.transfer_query2);
			preparedStatement.setLong(1,accno);	
			resultSet=preparedStatement.executeQuery();
						while(resultSet.next()) {
							t.setTid(resultSet.getInt("transid"));
							t.setAccNo(resultSet.getInt("accountno"));
							t.setAmt(resultSet.getDouble("amount"));
							t.setTtype(resultSet.getString("transfertype"));
							t.settDate(resultSet.getDate("transDate"));
							System.out.println(t);
			}
		}catch(SQLException sqlException)
		{
		logger.error(sqlException.getMessage());
		sqlException.printStackTrace();
		throw new WalletException("Tehnical problem occured refer log");
	}
	finally
	{
		try 
		{
			preparedStatement.close();
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			logger.error(sqlException.getMessage());
			throw new WalletException("Error in closing db connection");	
		}
	}return false;
	}
	



	 
	}



