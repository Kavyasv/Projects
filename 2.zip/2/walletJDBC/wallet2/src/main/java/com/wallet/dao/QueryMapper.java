package com.wallet.dao;

public interface QueryMapper {
	public static final String INSERT_QUERY="INSERT INTO WalletDetails VALUES(accountNo_sequence.NEXTVAL,?,?,?,?,?,?)";
	public static final String ACCOUNTNO_QUERY_SEQUENCE="SELECT accountNo_sequence.CURRVAL FROM DUAL";
    public static final String SELECT_QUERY="SELECT balance from WALLETDETAILS WHERE account_No=?";
   public static final String DEPOSIT_QUERY="update WalletDetails set balance = balance + ? where account_No=?";
    public static final String WITHDRAW_QUERY="update WalletDetails set balance = balance - ? where account_No=?";
    public static final String INSERT_TRANSACTION="INSERT INTO TRANSACTION VALUES(transaction_sequence.NEXTVAL,?,?,?)";
    public static final String PRINT_TRANSACTION="SELECT trid,accnumber,amount,trtype FROM transaction WHERE accnumber = ?";
    public static final String ACCOUNTNO_SEQUENCE="SELECT CUSTOMER_SEQUENCE.CURRVAL FROM DUAL";
    public static final String transfer_query1="insert into transaction values(transid_sequence.NEXTVAL,?,?,?,?)";
    public static final String date_query="select sysdate from dual";
    public static final String transfer_query_sequence="select transaction_sequence.CURRVAL from dual";
    public static final String transfer_query2="select * from transaction where accountno=?";
}
/******************TABLESCRIPT*******************
create table WalletDetails(accnumber number(10),
name varchar2(30),
mobile varchar2(10),
email varchar2(30),
address varchar2(40),
balance number,
pin number);


CREATE SEQUENCE accountNo_sequence START WITH 1 Increment by 1;


create table transfer
(transid number(5),
transfertype varchar2(20),
amount number(10),
transDate date,
accountno number(12)); 
 
 
 create sequence transaction_sequence;
************************************************/