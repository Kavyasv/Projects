package com.cg.dao;

import java.util.List;

import org.cap.model.ProductDetails;

public interface IProductDao {

	public List<ProductDetails> getProducts();

	public ProductDetails findProduct(Integer id);

	public void updateProduct(ProductDetails product1);

}
