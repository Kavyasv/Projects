package org.cap.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {
@RequestMapping("/hello")
public ModelAndView sayHello() {
	String message="good morning";
	return new ModelAndView("hello","msg",message);
	
}

@PostMapping("/validateform")
public String validatePage(ModelMap map,@RequestParam("username")String username, @RequestParam("pward")String pward) {
	if(username.equals("kav")&&(pward.equals("123"))) {
		return "Success";
	}
	return "redirect:/";
	}
}
