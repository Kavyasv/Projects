package com.me.listener;

import java.util.Date;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class MyHttpSessionListener
 *
 */
public class MyHttpSessionListener implements HttpSessionListener {

	/**
	 * Default constructor.
	 */
	public MyHttpSessionListener() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
	 */
	public void sessionCreated(HttpSessionEvent hse) {
		// TODO Auto-generated method stub
		HttpSession session = hse.getSession();

		System.out.println("Session got created at: " + session.getCreationTime());
	}

	/**
	 * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
	 */
	public void sessionDestroyed(HttpSessionEvent hse) {
		// TODO Auto-generated method stub
		HttpSession session = hse.getSession();

		System.out.println("Session got destroyed at: " + new Date(System.currentTimeMillis()));
	}

}
