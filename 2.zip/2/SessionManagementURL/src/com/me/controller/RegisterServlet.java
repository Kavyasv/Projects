package com.me.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		ServletConfig sc = getServletConfig(); 
		
		String driver = sc.getInitParameter("driver");
	
		String url = sc.getInitParameter("url");
		String username = sc.getInitParameter("username");
		String password = sc.getInitParameter("password");
		
		String query = new String("INSERT INTO emp VALUES(?,?,?)");
		
		int empid = Integer.parseInt(request.getParameter("empid"));
		String name = request.getParameter("name");
		float salary = Float.parseFloat(request.getParameter("salary"));
		Connection connDB = null;
		PreparedStatement ps = null;
		try{
			Class.forName(driver);
			
			connDB = DriverManager.getConnection(url, username, password);
			ps = connDB.prepareStatement(query);
			
			ps.setInt(1, empid);
			ps.setString(2, name);
			ps.setFloat(3, salary);
			
			int status = ps.executeUpdate();
			
			if(status == 1){
				out.println("Record inserted successfully.");
			}else{
				out.println("Unable to insert record.");
			}
		}catch (ClassNotFoundException cnfe) {
			// TODO: handle exception
			out.println(cnfe.getMessage());
		}catch (SQLException se) {
			// TODO: handle exception
			out.println(se.getMessage());
		}finally{
			try {
				connDB.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				out.println(e.getMessage());
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}