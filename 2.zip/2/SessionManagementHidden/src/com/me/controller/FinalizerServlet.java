package com.me.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FinalizerServlet
 */
public class FinalizerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FinalizerServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String[] items = {"Pen Drive", "8 GB RAM"};
		int[] rates = {500,3000};
		int[] purchasedQuantities = new int[2];
		int i = 0;
		int totalPrice = 0;
		String purchased = request.getParameter("id") + ";"+request.getParameter("ram");
		
		StringTokenizer tokens = new StringTokenizer(purchased, ";");
		
		tokens.nextToken();
		
		while(tokens.hasMoreElements()){
			purchasedQuantities[i] = Integer.parseInt(tokens.nextToken());
			
			if(purchasedQuantities[i] != 0){
				int price = purchasedQuantities[i] * rates[i];
				out.print(items[i] + ": " + price + "<br/>");
				totalPrice += price;
			}
			i++;
		}
		
		out.print("Total Purchase Price: " + totalPrice);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
