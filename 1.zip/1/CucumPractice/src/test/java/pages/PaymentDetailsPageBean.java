package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PaymentDetailsPageBean {
	
	WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement cardHolderName;
	
	@FindBy(name="debit")
	private WebElement dbCardNumber;
	
	@FindBy(name="cvv")
	private WebElement cvv;
	
	@FindBy(name="month")
	private WebElement expiryDate;
	
	@FindBy(name="year")
	private WebElement expiryYear;
	
	
	@FindBy(how=How.XPATH,using="//*[@id=\"btnPayment\"]")
	private WebElement btn2;
	
	public PaymentDetailsPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}

	public void setDbCardNumber(String dbCardNumber) {
		this.dbCardNumber.sendKeys(dbCardNumber);
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate.sendKeys(expiryDate);
	}

	public void setExpiryYear(String expiryYear) {
		this.expiryYear.sendKeys(expiryYear);
	}

	public void setBtn2() {
		this.btn2.click();
	}
	
	
	
	
}
