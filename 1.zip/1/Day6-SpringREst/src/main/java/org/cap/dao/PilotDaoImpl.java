package org.cap.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.cap.model.Pilot;
import org.springframework.stereotype.Repository;

@Repository("pilotDao")
public class PilotDaoImpl implements IPilotDao{
	
	private static AtomicInteger pilotId=new AtomicInteger(1000);
	
	 
	private static List<Pilot> pilots=dummyDbPilot();
	
	private static List<Pilot> dummyDbPilot(){
		List<Pilot> pilots=new ArrayList<>();
		
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Tom", "Jerry", new Date(1991, 3, 12), new Date(), true, 23000));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Jack", "Jerry", new Date(1997, 6, 19), new Date(), true, 34000));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Jessi", "Jerry", new Date(1987, 3, 23), new Date(2013,3,12), false, 21321));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Ram", "Singh", new Date(1991, 10, 12), new Date(2019,1,12), true, 670000));
		pilots.add(new Pilot(pilotId.incrementAndGet(), "Vishal", "Singh", new Date(1991, 11, 10), new Date(), false, 90000));
		
		return pilots;
	}

	@Override
	public List<Pilot> getAllPilots() {
		
		return pilots;
	}

	@Override
	public Pilot findPilot(Integer pilotId) {
		for(Pilot pilot:pilots) {
			if(pilot.getPilotId()==pilotId) {
				return pilot;
			}
		}
		return null;
	}

	@Override
	public List<Pilot>  deletePilot(Integer pilotId) {
	Iterator<Pilot> iterator=pilots.iterator();
	while(iterator.hasNext()) {
		Pilot pilot=iterator.next();
		boolean flag=false;
		if(pilot.getPilotId()==pilotId) {
			iterator.remove();
			flag=true;
			break;
		}
		if(flag)
			return pilots;
			
	}
	return null;
	
	
	}

	@Override
	public List<Pilot> createPilot(Pilot pilot) {
		pilots.add(pilot);
		return pilots;
	}

	/*@Override
	public List<Pilot> updatePilot(Pilot pilot) {
		if(pilot.getPilotId()!=0) {
			pilots.set(0, pilot);
		}
		else
			pilots.add(pilot);
		return pilots;
	}*/


}
