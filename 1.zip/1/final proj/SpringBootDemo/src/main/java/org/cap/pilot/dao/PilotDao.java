package org.cap.pilot.dao;


import org.cap.pilot.model.Pilot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository("pilotDao")
public interface PilotDao extends JpaRepository<Pilot,Integer>{
	
}
