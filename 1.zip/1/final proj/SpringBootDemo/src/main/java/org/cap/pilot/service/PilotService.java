package org.cap.pilot.service;

import java.util.List;

import org.cap.pilot.model.Pilot;







public interface PilotService {
	
	
	public void save(Pilot pilot);
	public List<Pilot> getAll();
	public void delete(Integer pilotId);
/*public	Pilot findPilotId( Integer pilotId);
	public void update(Pilot pilot);
		*/
	
}
