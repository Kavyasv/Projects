package com.cg.service;

import java.util.List;

import com.cg.hotel.HotelDetails;

public interface IBookingService {

	public List<HotelDetails> getAllHotels();

	public HotelDetails getHotelPageByName(String hName);

}
