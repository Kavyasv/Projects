package com.cg.dao;

import java.util.List;

import com.cg.hotel.HotelDetails;

public interface IBookingDAO {

	public List<HotelDetails> getAllHotels();

	public HotelDetails getHotelPageByName(String hName);

}
