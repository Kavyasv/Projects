package org.cap.model;


import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.validation.constraints.Future;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

@Entity
public class Pilot  {
	
	@Id
	@GeneratedValue
	private int pilotId;
	@NotEmpty(message="*please enter firstName.")
	private String firstName;
	private String lastName;
	
	@NotNull(message="* Please enter Date Of Birth.")
	@Past(message="* Please enter past date.")
	private Date dob;
	
	@Future(message="* Please nter future date.")
	private Date doj;
	private Boolean isCertified;
	
	@Range(min=10000,max=200000,message="*Salary should be between 10000 and 2laks.")
	private double salary;

@Email(message="* please enter valid email ")
private String email;
public int getPilotId() {
	return pilotId;
}
public String getFirstName() {
	return firstName;
}
public Pilot() {
	
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}

public Boolean getIscertified() {
	return isCertified;
}
public void setIscertified(Boolean iscertified) {
	this.isCertified = iscertified;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public void setPilotId(int pilotId) {
	this.pilotId = pilotId;
}

public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public Date getDoj() {
	return doj;
}
public void setDoj(Date doj) {
	this.doj = doj;
}


public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
@Override
public String toString() {
	return "Pilot [pilotId=" + pilotId + ", firstName=" + firstName + ", lastName=" + lastName + ", dob=" + dob
			+ ", doj=" + doj + ", iscertified=" + isCertified + ", salary=" + salary + ", email=" + email + "]";
}
public Pilot(int pilotId, String firstName, String lastName, Date dob, Date doj, Boolean iscertified, double salary,
		String email) {
	super();
	this.pilotId = pilotId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.dob = dob;
	this.doj = doj;
	this.isCertified = iscertified;
	this.salary = salary;
	this.email = email;
}


}
